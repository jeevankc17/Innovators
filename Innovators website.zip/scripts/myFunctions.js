//thankyou alert//
function tyAlert() {
  alert("Thank you for your keen interest.Keep in touch!")
}

      
function mLearning() {
  window.open("ml.html", "_blank","width=610,height=360")
}

function eHacking() {
  window.open("eh.html", "_blank", "width=610,height=360")
  
}

function wDevelopment() {
  window.open("wd.html", "_blank", "width=610,height=360")
  
}
